import cv2
print("OpenCV Version:", cv2.__version__)

car_cascade = cv2.CascadeClassifier("cascades/cars.xml")
person_cascade = cv2.CascadeClassifier("cascades\haarcascade_fullbody.xml")


video_src = "dataset\my_new_video.mp4"
cap = cv2.VideoCapture(video_src)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)   # improves Haar detection!

    # DETECT objects
    cars = car_cascade.detectMultiScale(gray, 1.1, 3)
    persons = person_cascade.detectMultiScale(gray, 1.05, 6)
   

    # Draw bounding boxes
    def draw_boxes(objects, label, color):
        for (x, y, w, h) in objects:
            cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
            cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX,
                        0.7, color, 2)

    draw_boxes(cars, "Car", (0, 255, 0))
    draw_boxes(persons, "Person", (0, 0, 255))
    

    # If nothing detected → mark as unknown
    if (len(cars) == 0  and len(persons) ):
        cv2.putText(frame, "Unknown Object", (30, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    1, (0, 255, 255), 2)

    cv2.imshow("Vehicle Detection (Improved Haar Cascades)", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()

